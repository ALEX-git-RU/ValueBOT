import requests
import json

class APIException(Exception):
    pass

class CurrencyConverter:
    keys = {
        'доллар': 'USD',
        'евро': 'EUR',
        'рубль': 'RUB'
    }

    @staticmethod
    def get_price(base: str, quote: str, amount: str):
        if base.lower() not in CurrencyConverter.keys or quote.lower() not in CurrencyConverter.keys:
            raise APIException("Неправильная или несуществующая валюта.")

        try:
            amount = float(amount)
        except ValueError:
            raise APIException("Количество должно быть числом.")


        url = f"https://min-api.cryptocompare.com/data/price?fsym={CurrencyConverter.keys[base.lower()]}&tsyms={CurrencyConverter.keys[quote.lower()]}"
        response = requests.get(url)
        if response.status_code != 200:
            raise APIException("Ошибка получения данных от API.")

        data = json.loads(response.text)
        if CurrencyConverter.keys[quote.lower()] not in data:
            raise APIException(f"Ошибка обработки данных для валюты {quote}.")

        rate = data[CurrencyConverter.keys[quote.lower()]]
        total_amount = rate * amount


        total_amount = round(total_amount, 2)

        return total_amount

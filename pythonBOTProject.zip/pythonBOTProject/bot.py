import telebot
from config import TOKEN
from extensions import APIException, CurrencyConverter

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    text = ("Чтобы узнать цену валюты, отправьте сообщение в формате:\n"
            "<имя валюты> <имя валюты для конвертации> <количество>\n"
            "Например: евро доллар 100\n"
            "Доступные команды:\n"
            "/start или /help - для вызова этого сообщения\n"
            "/values - для отображения всех доступных валют")
    bot.reply_to(message, text)

@bot.message_handler(commands=['values'])
def send_values(message):
    text = "Доступные валюты:\nЕвро, Доллар, Рубль"
    bot.reply_to(message, text)

@bot.message_handler(content_types=['text'])
def convert_currency(message):
    try:
        values = message.text.split()
        if len(values) != 3:
            raise APIException("Неправильное количество параметров.")

        base, quote, amount = values
        total_amount = CurrencyConverter.get_price(base, quote, amount)
    except APIException as e:
        bot.reply_to(message, f"Ошибка: {e}")
    except Exception as e:
        bot.reply_to(message, f"Ошибка: {type(e).__name__} - {e}")
    else:
        text = f"Цена {amount} {base} в {quote} составляет {total_amount}"
        bot.reply_to(message, text)

bot.polling()